# Luna handoff: candidate tasks 21–30

Base contract: `abd36b96d0d2c9f79a3966ae45a680ef16afdd93`.

These tasks are authoring candidates, not sealed/formal slots. Work in an isolated branch/worktree. Do not modify ACRE/CEGIS/router/governance to make a task pass.

Recommended order:

1. `CORE-SCALAR-SYNC-LOW-CADENCE-21` — counterexample. Confirm a safe scalar aggregation does not clear the empirical noise/min-improvement margin. If it does on CUDA, recalibrate or retire the task; do not force abstention by weakening semantics.
2. `CORE-REPEATED-BACKBONE-LOW-REUSE-22` — counterexample. The tempting reuse of the first backbone activation for the second distinct input must fail hidden correctness.
3. `CORE-H2D-OVERFANOUT-23` — CUDA counterexample. Calibrate on the target GPU with worker/pinning telemetry; this bundle could not perform authoritative CUDA validation.
4. `CORE-CHECKPOINT-HIGH-PRESSURE-24` — positive. CPU smoke is only ~1.1–1.3×; verify the mechanism on the intended GPU/memory regime. Keep logical batch, loss normalization, and gradient update identical.
5. `CORE-AUTOGRAD-VJP-SMALL-25` — counterexample. `is_grads_batched=True` is correct but did not reliably clear 5% in CPU smoke. Recheck on the target runtime.
6. `SCIML-EQUIV-LOWORDER-26` — positive. Reference reuses only the invariant radial scalar path. Preserve SO(3) equivariance.
7. `SCIML-GRAPH-CACHE-BOUNDARY-27` — positive boundary anchor at `geometry_displacement=0.05`. Validate cached topology and exact energy/force gradients.
8. `SCIML-CRYSTAL-HIGH-GUIDANCE-28` — counterexample. Half-step sampling is faster but fails structure validity; preserve the quality threshold.
9. `SCIML-CRYSTAL-STATIC-SAMPLING-29` — positive. Reference vectorizes exact neighbor rebuilds; do not replace it with stale-graph caching.
10. `EVOL-EQUIVARIANT-SPECIALIZE-30` — run only after tasks 26 and existing task 06 are available in the same full repo. Baseline C vs governed D should test specialization of an `irrep_order<=1` rule across scientific-regime drift.

For each atomic task before admission:

```bash
python -m benchmark.harness.cli validate-task <task-dir>
# create task×outer-trial noise-control artifact under the current formal policy
# run at least 3 independent baseline/oracle calibrations on the target environment
# verify correctness, scientific gates, S4 exactly-one action, work units, timeout, and no process survivors
```

Do not edit `benchmark/manifests/v1.0-50-slots.json` or the current formal split while authoring these candidates. A Luna-optimized public candidate must not later be reused verbatim as a sealed evaluation task; generate a disjoint lineage/seed/fixture descendant.
