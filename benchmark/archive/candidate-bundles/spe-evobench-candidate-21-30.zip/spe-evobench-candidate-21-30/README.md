# SPE-EvoBench candidate tasks 21–30

Base repository revision: `abd36b96d0d2c9f79a3966ae45a680ef16afdd93`.

These ten packages are **authoring/calibration candidates**, not formal v1.0-50 slots. Do not copy them wholesale into `benchmark/tasks/` on `main`: the current population validator freezes a 20-task pilot count and the formal manifest explicitly gates remaining slots on empirical calibration.

Use an isolated worktree/branch. Validate each task independently, calibrate baseline/oracle/noise, then decide whether a public-dev derivative or a separately generated sealed lineage should enter the formal population.

The bundle deliberately reuses current FamilySpec/ActionSpec names. It does not modify ACRE, CEGIS, router, governance, formal split, or the v1.0-50 manifest.

Local validation in this archive is package-level only. CUDA task 23 and evolution task 30 require the full repository/runtime for authoritative validation.
