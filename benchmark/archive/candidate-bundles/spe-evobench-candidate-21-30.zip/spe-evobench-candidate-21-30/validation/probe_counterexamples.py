from pathlib import Path
import importlib.util, tempfile, statistics, json
ROOT=Path(__file__).resolve().parents[1]/'benchmark'/'tasks'

def load(path,name):
    s=importlib.util.spec_from_file_location(name,path); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m
report={}
# 21 safe aggregation should not clear 5% authoring margin reliably.
p=ROOT/'CORE-SCALAR-SYNC-LOW-CADENCE-21'; b=load(p/'benchmark.py','b21'); fx=b.make_fixtures(0,'cpu'); base=b.load_solution(p/'workspace/solution.py'); src=(p/'workspace/solution.py').read_text().replace("values=[metrics[i].item() for i in range(4)]","values=metrics.tolist()")
with tempfile.TemporaryDirectory() as td:
    f=Path(td)/'solution.py'; f.write_text(src); cand=b.load_solution(f); ratios=[]
    for _ in range(7):
        pb=b.run_performance(base,fx,warmup=5,iterations=60,device='cpu')['value']; pc=b.run_performance(cand,fx,warmup=5,iterations=60,device='cpu')['value']; ratios.append(pb/pc)
    report[p.name]={'probe':'aggregate metrics via tolist','correctness':b.run_correctness(cand,fx)['passed'],'science':all(v[0] for v in b.run_scientific_gates(cand,fx).values()),'speedups':ratios,'median_speedup':statistics.median(ratios),'clears_5_percent':statistics.median(ratios)>=1.05}
# 22 unsafe reuse must fail hidden correctness.
p=ROOT/'CORE-REPEATED-BACKBONE-LOW-REUSE-22'; b=load(p/'benchmark.py','b22'); fx=b.make_fixtures(0,'cpu'); src=(p/'workspace/solution.py').read_text().replace("def forward_pair(self,x1,x2): return self.h1(self.backbone(x1)).squeeze(-1), self.h2(self.backbone(x2)).squeeze(-1)","def forward_pair(self,x1,x2):\n        h=self.backbone(x1); return self.h1(h).squeeze(-1), self.h2(h).squeeze(-1)")
with tempfile.TemporaryDirectory() as td:
    f=Path(td)/'solution.py'; f.write_text(src); cand=b.load_solution(f); report[p.name]={'probe':'reuse x1 backbone activation for x2','correctness':b.run_correctness(cand,fx)['passed'],'science':all(v[0] for v in b.run_scientific_gates(cand,fx).values())}
# 23 requires real CUDA.
report['CORE-H2D-OVERFANOUT-23']={'probe':'per-step pin_memory + non_blocking','status':'requires_cuda_server_calibration'}
# 25 mathematically correct batched VJP but small-output performance should not reliably clear margin.
p=ROOT/'CORE-AUTOGRAD-VJP-SMALL-25'; b=load(p/'benchmark.py','b25'); fx=b.make_fixtures(0,'cpu'); base=b.load_solution(p/'workspace/solution.py'); src=(p/'workspace/solution.py').read_text().replace("grads=[]\n    for i in range(y.numel()): grads.append(torch.autograd.grad(y[i],x,retain_graph=True,create_graph=True)[0])\n    return torch.stack(grads)","eye=torch.eye(y.numel(),device=y.device,dtype=y.dtype)\n    return torch.autograd.grad(y,x,grad_outputs=eye,is_grads_batched=True,create_graph=True,retain_graph=True)[0]")
with tempfile.TemporaryDirectory() as td:
    f=Path(td)/'solution.py'; f.write_text(src); cand=b.load_solution(f); ratios=[]
    for _ in range(7):
        pb=b.run_performance(base,fx,warmup=2,iterations=12,device='cpu')['value']; pc=b.run_performance(cand,fx,warmup=2,iterations=12,device='cpu')['value']; ratios.append(pb/pc)
    report[p.name]={'probe':'is_grads_batched=True','correctness':b.run_correctness(cand,fx)['passed'],'science':all(v[0] for v in b.run_scientific_gates(cand,fx).values()),'speedups':ratios,'median_speedup':statistics.median(ratios),'clears_5_percent':statistics.median(ratios)>=1.05}
# 28 step skipping must fail structure validity.
p=ROOT/'SCIML-CRYSTAL-HIGH-GUIDANCE-28'; b=load(p/'benchmark.py','b28'); fx=b.make_fixtures(0,'cpu'); src=(p/'workspace/solution.py').read_text().replace("for i in range(num_steps): state=sample_step(sampler,state,i)","for i in range(0,num_steps,2): state=sample_step(sampler,state,i)")
with tempfile.TemporaryDirectory() as td:
    f=Path(td)/'solution.py'; f.write_text(src); cand=b.load_solution(f); sci=b.run_scientific_gates(cand,fx); report[p.name]={'probe':'execute every second sampling step','correctness':b.run_correctness(cand,fx)['passed'],'science':all(v[0] for v in sci.values()),'details':sci}
(Path(__file__).with_name('counterexample_probe_report.json')).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
