from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]
TASKS = ROOT / 'benchmark' / 'tasks'
EXPECTED = {
    'CORE-SCALAR-SYNC-LOW-CADENCE-21',
    'CORE-REPEATED-BACKBONE-LOW-REUSE-22',
    'CORE-H2D-OVERFANOUT-23',
    'CORE-CHECKPOINT-HIGH-PRESSURE-24',
    'CORE-AUTOGRAD-VJP-SMALL-25',
    'SCIML-EQUIV-LOWORDER-26',
    'SCIML-GRAPH-CACHE-BOUNDARY-27',
    'SCIML-CRYSTAL-HIGH-GUIDANCE-28',
    'SCIML-CRYSTAL-STATIC-SAMPLING-29',
    'EVOL-EQUIVARIANT-SPECIALIZE-30',
}
REQUIRED = {
    'task.yaml','metadata.json','benchmark.py','scientific_contract.py',
    'workspace/solution.py','workspace/README.md','public_tests/test_public.py',
    'hidden_verifier/checks.py','oracle/solution_oracle.py','oracle/expected_mechanism.json',
    'oracle/bottleneck.json','oracle/tempting_wrong_patch.md','oracle/noise_floor.json',
    'oracle/validation.json','oracle/reference_patch.diff',
}

def test_all_task_packages_exist():
    assert TASKS.is_dir()
    found = {p.name for p in TASKS.iterdir() if p.is_dir()}
    assert found == EXPECTED


def test_required_files_present():
    for task_id in EXPECTED:
        task = TASKS / task_id
        missing = [rel for rel in REQUIRED if not (task / rel).is_file()]
        assert not missing, (task_id, missing)


def test_candidate_manifest_covers_exactly_ten():
    manifest = json.loads((ROOT / 'candidate_manifest.json').read_text())
    assert {x['task_id'] for x in manifest['tasks']} == EXPECTED
    assert manifest['base_revision'] == 'abd36b96d0d2c9f79a3966ae45a680ef16afdd93'
