from __future__ import annotations
import ast, hashlib, importlib.util, json, math, shutil, statistics, subprocess, tempfile
from pathlib import Path
import yaml

ROOT=Path(__file__).resolve().parents[1]
TASKS=ROOT/'benchmark'/'tasks'
EXPECTED_ACTION={
 'CORE-SCALAR-SYNC-LOW-CADENCE-21':'aggregate_scalars',
 'CORE-REPEATED-BACKBONE-LOW-REUSE-22':'reuse_backbone',
 'CORE-H2D-OVERFANOUT-23':'pin_memory_pipeline',
 'CORE-CHECKPOINT-HIGH-PRESSURE-24':'checkpoint_recompute',
 'CORE-AUTOGRAD-VJP-SMALL-25':'batched_vjp',
 'SCIML-EQUIV-LOWORDER-26':'equivariant_recompute',
 'SCIML-GRAPH-CACHE-BOUNDARY-27':'reuse_graph_cache',
 'SCIML-CRYSTAL-HIGH-GUIDANCE-28':'sampling',
 'SCIML-CRYSTAL-STATIC-SAMPLING-29':'graph_rebuild',
 'EVOL-EQUIVARIANT-SPECIALIZE-30':'rule_update',
}
VALIDATOR_METRIC={
 'aggregate_scalars':('aggregated_scalar_syncs','less'),
 'reuse_backbone':('backbone_reused','bool'),
 'pin_memory_pipeline':('pin_nonblocking_overlap','bool'),
 'checkpoint_recompute':('checkpoint_recompute_calls','neq'),
 'batched_vjp':('batched_vjp_calls','neq'),
 'equivariant_recompute':('equivariant_path_calls','neq'),
 'reuse_graph_cache':('cache_hit_without_rebuild','bool'),
 'sampling':('crystal_sampler_calls','neq'),
 'graph_rebuild':('graph_rebuild_count','greater'),
 'rule_update':('transition_applied','bool'),
}

def load(path,name):
    s=importlib.util.spec_from_file_location(name,path); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m

def ast_hash(td):
    def norm(node):
        f=[node.__class__.__name__]; seen=set()
        for name,val in ast.iter_fields(node):
            seen.add(name)
            if isinstance(val,ast.AST): f.append((name,norm(val)))
            elif isinstance(val,list): f.append((name,[norm(x) if isinstance(x,ast.AST) else type(x).__name__ for x in val]))
            elif name in {'ctx','type_comment','kind'}: f.append((name,type(val).__name__ if val is not None else None))
            else: f.append((name,type(val).__name__))
        if node.__class__.__name__ in {'FunctionDef','AsyncFunctionDef','ClassDef'} and 'type_params' not in seen: f.append(('type_params',[]))
        return f
    chunks=[]
    for p in sorted((td/'workspace').rglob('*.py')): chunks.append(p.relative_to(td).as_posix()+'\n'+json.dumps(norm(ast.parse(p.read_text())),sort_keys=True,separators=(',',':')))
    return hashlib.sha256('\n'.join(chunks).encode()).hexdigest()

def family_digest(fid,params):
    return hashlib.sha256(json.dumps({'family_id':fid,'parameters':params},sort_keys=True,separators=(',',':'),ensure_ascii=True).encode()).hexdigest()

def applicable(fid,p):
    if fid=='scalar_sync': return int(p['scalar_syncs_per_step'])>8
    if fid=='repeated_compute': return int(p['repeat_count'])>=4
    if fid=='h2d_pipeline': return bool(p['pin_memory']) and int(p['worker_count'])<=4
    if fid=='checkpoint': return float(p['memory_pressure'])>=0.57
    if fid=='autograd': return int(p['output_count'])>=8
    if fid=='equivariant_head': return int(p['irrep_order'])<2
    if fid=='graph_cache': return float(p['geometry_displacement'])<=0.05
    if fid=='crystal_generation': return float(p['guidance_scale'])<=3.0
    if fid=='crystal_sampling': return float(p['geometry_variation'])<=0.35
    if fid=='episode': return float(p['drift_rate'])<=0.45
    raise KeyError(fid)

def gates_pass(g):
    return all(bool(v[0] if isinstance(v,(tuple,list)) else v.get('passed',False) if isinstance(v,dict) else v) for v in g.values())

def action_matches(metrics,baseline,action):
    metric,kind=VALIDATOR_METRIC[action]; c=metrics.get(metric); b=baseline.get(metric)
    if kind=='bool': return bool(c) and not bool(b)
    if not isinstance(c,(int,float)) or not isinstance(b,(int,float)): return False
    if kind=='less': return c<b
    if kind=='greater': return c>b
    return c!=b

def validate_patch(td):
    diff=(td/'oracle/reference_patch.diff').read_text()
    if diff.startswith('# Correct action is abstention'): return True,'abstention-noop'
    with tempfile.TemporaryDirectory() as raw:
        tmp=Path(raw); shutil.copy2(td/'workspace/solution.py',tmp/'solution.py'); (tmp/'p.diff').write_text(diff)
        cp=subprocess.run(['patch','-p1','-i','p.diff'],cwd=tmp,text=True,capture_output=True)
        return cp.returncode==0 and (tmp/'solution.py').read_text()==(td/'oracle/solution_oracle.py').read_text(), cp.stdout+cp.stderr

errors=[]; report={'base_revision':'abd36b96d0d2c9f79a3966ae45a680ef16afdd93','tasks':[]}
for td in sorted(TASKS.iterdir()):
    spec=yaml.safe_load((td/'task.yaml').read_text()); row={'task_id':td.name,'kind':spec['kind'],'family_id':spec['family_id']}
    if ast_hash(td)!=spec['workspace_ast_skeleton_hash']: errors.append(f'{td.name}: AST skeleton mismatch')
    if family_digest(spec['family_id'],spec['family_parameters'])!=spec['family_instance_digest']: errors.append(f'{td.name}: family digest mismatch')
    truth=applicable(spec['family_id'],spec['family_parameters']); expected=(spec['kind']=='positive')
    if truth!=expected: errors.append(f'{td.name}: polarity/applicability mismatch {truth} vs {spec["kind"]}')
    ok,msg=validate_patch(td); row['reference_patch_equivalent']=ok
    if not ok: errors.append(f'{td.name}: reference patch does not reconstruct oracle: {msg}')
    row['public_test_pass']='validated_in_batch'
    if td.name.startswith('EVOL-'):
        bsrc=(td/'workspace/solution.py').read_text(); osrc=(td/'oracle/solution_oracle.py').read_text(); ep=yaml.safe_load((td/'episodes/equivariant_specialization_episode.yaml').read_text())
        row.update({'execution':'requires_full_repo_evolution_harness','phase_count':len(ep.get('phases',[])),'baseline_condition_C':"condition='C'" in bsrc,'oracle_condition_D':"condition='D'" in osrc,'expected_action':'rule_update'})
        if len(ep.get('phases',[]))!=6 or "condition='C'" not in bsrc or "condition='D'" not in osrc: errors.append(f'{td.name}: episode structure invalid')
        report['tasks'].append(row); continue
    bench=load(td/'benchmark.py','bench_'+td.name.replace('-','_')); base=bench.load_solution(td/'workspace/solution.py'); oracle=bench.load_solution(td/'oracle/solution_oracle.py'); fx=bench.make_fixtures(0,'cpu')
    bc=bench.run_correctness(base,fx); oc=bench.run_correctness(oracle,fx); bs=bench.run_scientific_gates(base,fx); os=bench.run_scientific_gates(oracle,fx)
    row.update({'baseline_correctness':bool(bc.get('passed')),'oracle_correctness':bool(oc.get('passed')),'baseline_science':gates_pass(bs),'oracle_science':gates_pass(os)})
    if not all((bc.get('passed'),oc.get('passed'),gates_pass(bs),gates_pass(os))): errors.append(f'{td.name}: baseline/oracle correctness/science failed')
    act=bench.run_activation_evidence(oracle,base,fx) if hasattr(bench,'run_activation_evidence') else None
    if act:
        matched=action_matches(act['candidate_metrics'],act['baseline_metrics'],EXPECTED_ACTION[td.name])
        row['oracle_activation_matches_action']=matched
        if spec['kind']=='positive' and not matched: errors.append(f'{td.name}: positive oracle activation does not match {EXPECTED_ACTION[td.name]}')
        if spec['kind']!='positive' and matched: errors.append(f'{td.name}: counterexample abstention oracle unexpectedly activates {EXPECTED_ACTION[td.name]}')
    if spec['kind']=='positive':
        ratios=[]
        for seed in (0,1,2):
            fx2=bench.make_fixtures(seed,'cpu'); b2=bench.load_solution(td/'workspace/solution.py'); o2=bench.load_solution(td/'oracle/solution_oracle.py')
            cfg=spec['measurement']
            try:
                pb=bench.run_performance(b2,fx2,warmup=cfg['warmup_iterations'],iterations=min(int(cfg['measured_iterations']),20),device='cpu')
                po=bench.run_performance(o2,fx2,warmup=cfg['warmup_iterations'],iterations=min(int(cfg['measured_iterations']),20),device='cpu')
            except TypeError:
                pb=bench.run_performance(b2,fx2); po=bench.run_performance(o2,fx2)
            ratios.append(float(pb['value'])/float(po['value']))
        row['local_cpu_speedups']=ratios; row['local_cpu_median_speedup']=statistics.median(ratios)
        if td.name!='CORE-H2D-OVERFANOUT-23' and min(ratios)<=1.0: errors.append(f'{td.name}: positive oracle not faster in CPU smoke: {ratios}')
    else:
        row['oracle_is_source_identical']=(td/'workspace/solution.py').read_bytes()==(td/'oracle/solution_oracle.py').read_bytes()
        if not row['oracle_is_source_identical']: errors.append(f'{td.name}: counterexample oracle must be abstention/no-op in this bundle')
    report['tasks'].append(row)

(ROOT/'validation/validation_report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'errors':errors,'validated_tasks':len(report['tasks'])},indent=2))
raise SystemExit(1 if errors else 0)
