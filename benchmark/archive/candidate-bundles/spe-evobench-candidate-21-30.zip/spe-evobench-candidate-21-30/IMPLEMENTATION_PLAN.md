# Candidate 21–30 implementation plan

Goal: add ten public authoring candidates that fill applicability-boundary and evolution-specialization gaps without changing the current formal population.

1. Keep every package self-contained under `benchmark/tasks/<id>`.
2. Reuse the current FamilySpec action IDs and scientific policy IDs.
3. Counterexamples 21/22/23/25/28 require abstention or a science-preserving no-op; their oracle file intentionally matches the baseline.
4. Positive tasks 24/26/27/29 ship a concrete reference realization for calibration only.
5. Evolution task 30 mirrors the existing episode_v1 runner contract and is not considered locally execution-validated without the repository evolution harness.
6. Before any formal admission: regenerate cross-view anchor metadata in `benchmark/families/catalog.py`, run `validate-task`, population/cross-view/leakage validators, three independent noise controls, three oracle paired runs, and review lineage separation.
