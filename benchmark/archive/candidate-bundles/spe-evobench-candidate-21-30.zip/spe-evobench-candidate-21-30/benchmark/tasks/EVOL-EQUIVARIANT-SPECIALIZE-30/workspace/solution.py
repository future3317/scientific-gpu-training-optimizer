from __future__ import annotations
import tempfile
from pathlib import Path
from typing import Any
TASK_VARIANT="EVOL-EQUIVARIANT-SPECIALIZE-30"
def run_episode_task(task_workspace:str, skill_view:dict[str,Any], budget:dict[str,Any])->dict[str,Any]:
    condition='C'
    from benchmark.harness import evolution
    episode_yaml=Path(task_workspace).parent/'episodes'/'equivariant_specialization_episode.yaml'; out=Path(tempfile.mkdtemp(prefix='spe_evo_equiv_')); result=evolution.run_episode(str(episode_yaml),condition,out); metrics=result.get('metrics',{}); precision=metrics.get('rule_precision'); neg=metrics.get('negative_transfer_rate'); score=(float(precision) if precision is not None else 0.0)*(1.0-(float(neg) if neg is not None else 0.0)); return {'episode_score':score,'episode_metrics':metrics,'condition_used':condition,'out_dir':str(out)}
