"""Authoring-only anchor data for an isolated calibration branch.

Do not import this file in the formal benchmark. It exists to make manual
FamilySpec integration mechanical and reviewable.
"""
import json
from pathlib import Path

CANDIDATE_ANCHORS = json.loads((Path(__file__).with_name('candidate_anchor_coordinates.json')).read_text())
