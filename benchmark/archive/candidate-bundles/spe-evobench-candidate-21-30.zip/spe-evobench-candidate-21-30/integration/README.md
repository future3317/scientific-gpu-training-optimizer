# Integration notes

Do not edit the formal 50-slot manifest for these candidates.

For an isolated calibration branch, add selected candidate IDs to the matching `FamilySpec.anchors` tuple and `_EXPLICIT_ANCHORS` using `candidate_anchor_coordinates.json`. Keep existing action_specs unchanged. After authoring calibration, public-dev and sealed descendants must use different mutation/template lineage and fixture seeds; Luna-optimized candidates are not sealed evaluation tasks.

Run in the full repository:

```bash
python -m benchmark.harness.cli validate-task <candidate-task-dir>
python -m benchmark.taskgen.validate_population --tasks-root <candidate-composed-task-root> --out <report>
python -m benchmark.harness.cli check-leakage benchmark/split/sequential.yaml
python -m pytest -q
```

The existing `EXPECTED_COUNTS` for v1.0-20 must not be changed merely to make candidates pass.
